# Futures Screener (Binance USDT-M)

Single-page app with tabs.

MVP:
- Densities (orderbook liquidity)

Later:
- Movers / Volatility
- Levels / VP
- Strategy Signals

Snapshots:
- git tags + tar.gz in _snapshots
