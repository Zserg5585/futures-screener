/**
 * Density detector — placeholder for future expansion.
 * Currently unused; index.js calculates densities inline.
 */
async function scan(params) {
  // TODO: implement full density scanning logic if needed
  return []
}

module.exports = {
  detector: { scan }
}
